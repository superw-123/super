import React from 'react';
import {connect} from 'dva';
import styles from './index.less';
import Tree from './components/Tree';
import TreeNodeItem from './components/TreeNodeItem';

class DataTree extends React.Component {
    constructor(props) {
        super(props);
        this.observer = null;
    }
    state = {
        expandedKeys: ['0-14'],
        autoExpandParent: true,
        treeHeight: 200
    };
    onExpand = (expandedKeys, node) => {
        this.setState({
            expandedKeys,
            autoExpandParent: false
        });
    };
    onCustomLabel = item => {
        return (
            <TreeNodeItem item={item}/>
        );
    };
    render() {
        const {treeData} = this.props.dataTree;
        const treeProps = {
            treeHeight: this.state.treeHeight,
            treeData,
            expandedKeys: this.state.expandedKeys,
            autoExpandParent: this.state.autoExpandParent,
            onCustomLabel: this.onCustomLabel,
            onExpand: this.onExpand
        };
        return (
            <div className={styles['tree-wrap']}>
                <Tree {...treeProps}/>
            </div>
        );
    }
}

export default connect(({dataTree, loading}) => ({dataTree, loading}))(DataTree);