import React from 'react';
import Styles from './index.less';
import {Popover} from 'antd';
import FieldList from '../FieldList';
import {connect} from 'dva';

class TreeNodeItem extends React.Component {
    state = {
        id: ''
    }
    onSelect = () => {
        this.setState({
            id: '6'
        });
        this.props.dispatch({
            type: 'tableSchema/getTableInfo'
        });
    };
    render() {
        const {tableSchema, item} = this.props;
        const tableData = tableSchema.tableData;
        return (
            <span onClick={this.onSelect}>
                <Popover content={<FieldList tableData={tableData} />}
                    title={'测试'}
                    placement="rightTop"
                    trigger="click"
                    visible={this.state.id === '6' ? true : false}
                    overlayClassName={Styles['drag-table-pop']}
                >
                    <span className={Styles['node-span']}>
                        {item.title}
                    </span>
                </Popover>
            </span>
        );
    }
}

export default connect(({tableSchema, loading}) => ({tableSchema, loading}))(TreeNodeItem);