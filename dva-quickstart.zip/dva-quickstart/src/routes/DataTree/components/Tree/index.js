import React from 'react';
import {Tree, Spin} from 'antd';
import {DownOutlined} from '@ant-design/icons';
const {DirectoryTree} = Tree;

let TreeComp = ({
    treeData,
    treeHeight,
    onCustomLabel,
    onExpand,
    expandedKeys,
    autoExpandParent
}) => {
    const renderTreeNodes = data => (
        data.map(item => {
            const {title, tree_id, children} = item;
            if (children && !item.hasOwnProperty('is_table')) {
                return {title: title, key: tree_id, children: renderTreeNodes(children)};
            } else {
                return {title: onCustomLabel(item), key: item.tree_id};
            }
        })
    );
    return (
        <div>
            { 
                treeData.length > 0 && !!treeHeight
                ? <DirectoryTree
                    switcherIcon={<DownOutlined />}
                    showIcon={false}
                    onExpand={onExpand}
                    expandedKeys={expandedKeys}
                    autoExpandParent={autoExpandParent}
                    height={treeHeight}
                    treeData={renderTreeNodes(treeData)}
                />
                : null
            }
        </div>
    );
};
TreeComp = React.memo(TreeComp);
export default TreeComp;